#!/usr/bin/perl
use strict;
use List::Util qw(sum);

my @layers = ("SRF", "DCM", "MES");

foreach my $layer (@layers) {
  my $otufile = "miTAG_profile_36235_new_$layer.txt";
  &CalOBSimilarity($otufile, "bray", $layer);
##taxonomic
  foreach my $distance_method ("bray") {
    foreach my $null_model ("ecosphere") {
      &CalTaxonomicSimilarity($distance_method, $null_model, $layer);
    }
  }
}

sub CalOBSimilarity() {
  my ($otufile, $distance_method, $layer) = @_;
  my $distance_method1 = $distance_method;
  my $transfer         = "binary" if $distance_method eq "sorensen";
  $distance_method1 = "bray" if $distance_method eq "sorensen";
  my $sen = qq`
	library(vegan)
	library(picante)
	transfer="$transfer"
	distance.method="$distance_method1"
	data<-read.table(file="$otufile",sep="\\t",header=T,row.names=1)
	data[is.na(data)]=0
	##transfer data if defined
	if(transfer == "binary"){
	  data = decostand(data, method="pa")  # only work for presence/absence data
	}else if(transfer == "integer"){
	  data = round(data, digits=0)
	}else{
	  data=data
	}
	##calculate observed beta dissimilarity and similarity
	beta.dist = vegdist(t(data),method = distance.method)
    similarity.ob = 1 - beta.dist
	##write similarity values to files
	similarity.ob<-as.matrix(similarity.ob)
	write.table(similarity.ob,file="data/$distance_method\_ob_tax_$layer.txt",quote=F,col.names=T,row.names=T,sep="\\t")
  `;
  open(R, ">r.tmp") or die "Can't open temp file to write";
  print R "$sen";
  close(R);
  system("R --vanilla --slave <r.tmp >r.out 2>r.tmp2");
}

sub CalTaxonomicSimilarity() {
  my ($distance_method, $null_model, $layer) = @_;
  my %stochasticity;
  my $distance_method1 = $distance_method;
  my $transfer         = "binary" if $distance_method eq "sorensen";
  $distance_method1 = "bray" if $distance_method eq "sorensen";
  for (my $i = 1; $i <= 1000; $i++) {
    my $prmfile = "data/$null_model\_$i\_$layer.txt";
    print "$prmfile\n";
    my $sen = qq`
	library(vegan)
	library(picante)
	null.model="$null_model"
	transfer="$transfer"
	distance.method="$distance_method1"
	PRM<-read.table(file="$prmfile",sep="\\t",header=T,row.names=1)
	PRM[is.na(PRM)]=0
	##transfer data if defined
	if(transfer == "binary"){
	  PRM = decostand(PRM, method="pa")  # only work for presence/absence data
	}else if(transfer == "integer"){
	  PRM = round(PRM, digits=0)
	}else{
	  PRM=PRM;
	}
    ##calculate permutated beta dissimilarity and similarity
	dist_pm = vegdist(t(PRM),method = distance.method)
    similarity.pm = 1- dist_pm
	##write similarity values to files
	similarity.pm<-as.matrix(similarity.pm)
	write.table(similarity.pm,file="data/$null_model\_$i\_$distance_method\_pm_tax_$layer.txt",quote=F,col.names=T,row.names=T,sep="\\t")
  `;
    open(R, ">r.tmp") or die "Can't open temp file to write";
    print R "$sen";
    close(R);
    system("R --vanilla --slave <r.tmp >r.out 2>r.tmp2");
  }
}
